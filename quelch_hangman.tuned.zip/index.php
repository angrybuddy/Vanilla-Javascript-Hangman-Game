<?php

function url1() {
  return sprintf(
    "%s://%s%s",
    isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http',
    $_SERVER['SERVER_NAME'],
    $_SERVER['REQUEST_URI']
  );
}

function host1() {
  return sprintf(
    "%s://%s",
    isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http',
    $_SERVER['SERVER_NAME']
  );
}

// get base64 encoding for the file, to print out images
        function to64 ( $pth ) {
            $path = $pth;
            if( ! file_exists($path) ) return '';
            $type = pathinfo($path, PATHINFO_EXTENSION);
            $data = file_get_contents($path);
            return 'data:image/' . $type . ';base64,' . base64_encode($data);
        }

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>Hangman Anti-corrupcion en Uruguay</title>

<meta name="description" content="Hangman - jeugo de anti-corrupcion">
<meta name="keywords" content="hangman, uruguay, corrupcion, anticorrupcion">

  	<meta property="og:title" content="Hangman Uruguay" />
	<meta property="og:type" content="website" />
	<meta property="og:url" content="<?php echo url1(); ?>" />
	<meta property="og:description" content="Juego de Anti-corrupcion. " />
	<meta property="og:image" content="<?php echo host1(); ?>/hangman-screenshot.png" /> 

    <meta name="twitter:title" content="Hangman Uruguay" />
    <meta name="twitter:description" content="Juego de Anti-corrupcion. " />
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:image" content="<?php echo host1(); ?>/hangman-screenshot.png"> 

<link href="data:image/x-icon;base64,AAABAAEAEBAAAAEAIABoBAAAFgAAACgAAAAQAAAAIAAAAAEAIAAAAAAAAAQAABILAAASCwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABgAAAEwAAACJAAAApwAAAJwAAABsAAAAHwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAATQAAAOAAAAD+AAAA2wAAAOYAAADXAAAA7wAAAPsAAACmAAAAGgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAZgAAAP0AAACmAAAAgQAAAOkAAADTAAAAEQAAAAUAAABfAAAA6wAAAOcAAAAuAAAAAAAAAAAAAAAAAAAALwAAAPkAAAB0AAAAUwAAAP4AAADcAAAAmwAAAGIAAAByAAAAIQAAACYAAADqAAAA5gAAABcAAAAAAAAAAAAAALAAAACnAAAAAAAAAJQAAAB0AAAAugAAAN0AAAAKAAAABgAAAIoAAAA0AAAAUwAAAP8AAACZAAAAAAAAAA4AAAD4AAAAJgAAAAkAAAAJAAAAAAAAAAAAAAAhAAAAFAAAAAAAAAADAAAAtwAAABEAAADZAAAA8gAAAAkAAAA1AAAA/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAF4AAABVAAAAoAAAAP8AAAAxAAAAOwAAAOsAAAAXAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA8AAAAewAAAJgAAAD/AAAAPAAAABgAAADjAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeAAAAGcAAAC7AAAA/wAAACAAAAAAAAAAwAAAAE4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJ0AAABUAAAA+gAAAN8AAAACAAAAAAAAADUAAADgAAAAJAAAAAAAAAAQAAAAGQAAAAAAAAAAAAAAAAAAAEcAAACMAAAAuQAAAP8AAAB8AAAAAAAAAAAAAAAAAAAAUgAAAN0AAABhAAAATwAAAJwAAAARAAAAEQAAAHwAAAC3AAAAtwAAAP8AAADZAAAACwAAAAAAAAAAAAAAAAAAAAAAAABHAAAAugAAALwAAADEAAAAxAAAAM4AAADEAAAA8AAAAP8AAADdAAAAJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQQAAAKkAAAD8AAAAxQAAAMcAAAD+AAAAsQAAAPwAAACgAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAZwAAAFoAAAC2AAAAzQAAAF8AAAAhAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAAADYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA8B8AAOAHAADAAwAAgAEAAIABAAAEQAAAH+AAAB/gAAAf4AAAH+AAAInBAADAAQAA4AMAAOAHAADwHwAA/n8AAA==" rel="icon" type="image/x-icon">

<style>
* { box-sizing: border-box; }
body { font-family: Tahoma, sans-serif; font-size: 16px;
  letter-spacing: 2px;  margin: 0; color: #333; }

img { max-width:100% }

a, a:visited { color: #00c }
a:hover, a:active { color: #c00 }

/* Column container */
.row {  
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  margin: 0;
  padding: 0;
}

.row::after {
  content: "";
  clear: both;
  display: table;
}

.center { 
  -ms-flex: 100%; /* IE10 */
  flex: 100%;
  padding: 8px; margin: 8px;
  text-align: center
}

.btn-hangman, .btn-hangman:visited {
    border: none; text-decoration: none;
    font-size: 18px; color: #000; background-color: #cec;
    border-radius: 4px; width: 28px; height: 28px;
    padding: 4px; margin: 1px;
    box-shadow: 1px 2px 2px #22c; 
}
.btn-hangman:active, .btn-hangman:hover { background-color: #c33; color: #fff }
.btn-hangman:disabled { color: #eee; background-color: #ccc }
</style>

</head>
<body>

<div class="row">
  <div class="center">
    <img id='hangmanPic' src="<?php echo to64('images/0.png'); ?>" alt="Hangman">
    <p id="questSpotlight">Ley de anti-corrupcion №17060, tambien lo llaman "Ley ?cual?":</p>
    <p id="wordSpotlight">xxxxxx</p>
    <div id="keyboard"></div>
  </div> 
</div>

<div class="row">
  <h1 class="center">Hangman</h1>
</div>
<div class="row">
  <div class="center">Under MIT license, Uruguay<br>&nbsp;</div>
</div>

<script>

var hangman_0 = [
    "<?php echo to64('images/0.png'); ?>",
    "<?php echo to64('images/1.png'); ?>",
    "<?php echo to64('images/2.png'); ?>",
    "<?php echo to64('images/3.png'); ?>",
    "<?php echo to64('images/4.png'); ?>",
    "<?php echo to64('images/5.png'); ?>",
    "<?php echo to64('images/6.png'); ?>"
]

var programming_languages = [
	[ "Ley anti-corrupcion №17060, tambien lo llaman la \"Ley ?adjetivo?\"", "cristal" ],
	[ "Segun Decreto №500/991 la ignorancia de una denuncia puede formar una falta ?adjetivo?", "grave"],
	[ "La Constitucion art.&nbsp;8 y los Derechos Humanos art.&nbsp;7 tratan de la ?que?", "igualdad" ],
	[ "La ley se refiere a encubierto y continuacion como circunstancias ?adjetivo plural?", "agravantes" ],
	[ "Cada funcionario publico debe responder por ?que manera? si un particular se lo pide", "escrito" ]
]

let answer = '';
let maxWrong = 6;
let mistakes = 0;
let guessed = [];
let wordStatus = null;

function randomWord() {
  var i = Math.floor(Math.random() * programming_languages.length);
  document.getElementById("questSpotlight").innerHTML = programming_languages[i][0];
  
  answer = programming_languages[i][1];
}

function generateButtons() {
  let buttonsHTML = 'abcdefghijklmnopqrstuvwxyz'.split('').map(letter =>
    `
      <button href="#"
        class="btn-hangman"
        id='` + letter + `'
        onClick="handleGuess('` + letter + `'); return false"
      >
        ` + letter + `
      </button>
    `).join('');

  document.getElementById('keyboard').innerHTML = buttonsHTML;
}

function handleGuess(chosenLetter) {
  guessed.indexOf(chosenLetter) === -1 ? guessed.push(chosenLetter) : null;
  document.getElementById(chosenLetter).setAttribute('disabled', true);

  if (answer.indexOf(chosenLetter) >= 0) {
    guessedWord();
    checkIfGameWon();
  } else if (answer.indexOf(chosenLetter) === -1) {
    mistakes++;
    updateMistakes();
    checkIfGameLost();
    updateHangmanPicture();
  }
}

function updateHangmanPicture() {
  document.getElementById('hangmanPic').src = hangman_0[mistakes];
}

function checkIfGameWon() {
  if (wordStatus === answer) {
    document.getElementById('keyboard').innerHTML = 'Has Ganado! <a href="#" onClick="reset(); return false"><small>Otra&nbsp;vez</small></a>';
  }
}

function checkIfGameLost() {
  if (mistakes === maxWrong) {
    document.getElementById('wordSpotlight').innerHTML = 'La&nbsp;respuesta: ' + answer;
    document.getElementById('keyboard').innerHTML = 'Has Perdido!!! <a href="#" onClick="reset(); return false"><small>Otra&nbsp;vez</small></a>';
  }
}

function guessedWord() {
  wordStatus = answer.split('').map(letter => (guessed.indexOf(letter) >= 0 ? letter : " _ ")).join('');

  document.getElementById('wordSpotlight').innerHTML = wordStatus;
}

function updateMistakes() {
  // document.getElementById('mistakes').innerHTML = mistakes;
  return 1
}

function reset() {
  mistakes = 0;
  guessed = [];
  document.getElementById('hangmanPic').src = hangman_0[0];

  randomWord();
  guessedWord();
  updateMistakes();
  generateButtons();
}

// document.getElementById('maxWrong').innerHTML = maxWrong;

randomWord();
generateButtons();
guessedWord();
    
    
</script>
</body>
</html>